package seleniumdemo;

public class SeleniumCheckbox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		  Launch new Browser
         Open DemoQA.com website
         Checkbox assignment :
   Identify the selected checkbox and display the name and value of the checkbox
   Identify the unselected checkbox and check the unselected one and display the name and value of newly selected button
		 */
	}

}
